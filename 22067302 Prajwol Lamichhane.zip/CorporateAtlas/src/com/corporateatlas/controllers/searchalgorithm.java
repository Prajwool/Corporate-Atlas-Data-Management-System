/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.corporateatlas.controllers;

import com.corporateatlas.models.DataModel;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * 
 */
public class searchalgorithm {
    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
    
   public static List<DataModel> search(
            int searchItem,
            List<DataModel> sort,
            int low,
            int high,
            String searchField
    ) {
        List<DataModel> resultModel = new ArrayList<>();

        while (low <= high) {
            int mid = low + (high - low) / 2;
            int midFieldValue = getField(sort.get(mid), searchField);

            if (midFieldValue == searchItem) {
                resultModel.add(sort.get(mid));

                int left = mid - 1;
                while (left >= low && getField(sort.get(left), searchField) == searchItem) {
                    resultModel.add(sort.get(left));
                    left--;
                }

                int right = mid + 1;
                while (right <= high && getField(sort.get(right), searchField) == searchItem) {
                    resultModel.add(sort.get(right));
                    right++;
                }

                return resultModel;
            }

            if (midFieldValue < searchItem) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        return resultModel;
    }

    private static int getField(DataModel dataModel, String searchField) {
        switch (searchField) {
            case "Profit":
                return dataModel.getProfit();
            // Add cases for other fields as needed...
            default:
                return -1; // Default return for fields not handled
        }
    }
}
