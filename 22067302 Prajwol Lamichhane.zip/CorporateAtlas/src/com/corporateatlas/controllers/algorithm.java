package com.corporateatlas.controllers;

import com.corporateatlas.models.DataModel;
import java.util.List;
import java.util.ArrayList;

public class algorithm {

    public static ArrayList<DataModel> selectionSort(List<DataModel> data, String sortBy, boolean ascending) {
        int n = data.size();

        for (int i = 0; i < n - 1; i++) {  // Corrected loop condition
            int minIndex = i;

            for (int j = i + 1; j < n; j++) {
                if (compare(data.get(j), data.get(minIndex), sortBy, ascending)) {
                    minIndex = j;
                }
            }        // Swap the found minimum element with the first element
            swap(data, i, minIndex);
        }
        ArrayList<DataModel> arrayListData = new ArrayList<>(data);
        return arrayListData;
    }

    private static boolean compare(DataModel a, DataModel b, String sortBy, boolean ascending) {
        int result;

        switch (sortBy) {
            case "Rank" -> result = Integer.compare(a.getRank(), b.getRank());
            case "Profit" -> result = Double.compare(a.getProfit(), b.getProfit());  // Added Profit case
            default -> throw new IllegalArgumentException("Invalid field for sorting: " + sortBy);
        }

        return ascending ? result > 0 : result < 0;
    }
    private static void swap(List<DataModel> data, int i, int j) {
        DataModel temp = data.get(i);
        data.set(i, data.get(j));
        data.set(j, temp);
    }
}
