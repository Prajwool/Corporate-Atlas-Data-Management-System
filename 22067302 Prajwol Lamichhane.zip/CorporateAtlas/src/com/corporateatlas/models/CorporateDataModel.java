/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.corporateatlas.models;

/**
 *
 * @author lamic
 */
import javax.swing.table.DefaultTableModel;

public class CorporateDataModel extends DefaultTableModel {

    public CorporateDataModel() {
        // Set column names
        super(new Object[]{"Rank", "Name", "Revenue", "Revenue Percent change", "Profit", "Profit Percent change", "Assets", "Market Value", "Employee", "Change in Rank(500 only)"}, 0);
        
        // Initial data
        addRow(new Object[]{"1", "Walmart", "523964", "1.9", "14881", "123.1", "236495", "321803", "2200000", "1"});
        addRow(new Object[]{"2", "Amazon", "280522", "20.5", "11588", "15", "225248", "970680", "798000", "3"});
        addRow(new Object[]{"3", "Exxon Mobil", "264938", "-8.7", "14340", "31.2", "362597", "160160696", "74900", "-1"});
        addRow(new Object[]{"4", "Apple", "260174", "-2", "55256", "7.2", "338516", "1112640", "137000", "-1"});
        addRow(new Object[]{"5", "Cvs Health", "256776", "32", "6634", "32", "222449", "77375", "290000", "3"});
    }

    // Add a method to retrieve data at a specific row
    public Object[] getRowData(int row) {
        int columnCount = getColumnCount();
        Object[] rowData = new Object[columnCount];
        for (int col = 0; col < columnCount; col++) {
            rowData[col] = getValueAt(row, col);
        }
        return rowData;
    }

    // Add a method to add a new row to the table
    public void addCorporateData(String[] data) {
        addRow(data);
    }

    // Add a method to update a specific row in the table
    public void updateCorporateData(int row, String[] data) {
        for (int col = 0; col < getColumnCount(); col++) {
            setValueAt(data[col], row, col);
        }
    }

    // Add a method to delete a specific row from the table
    public void deleteCorporateData(int row) {
        removeRow(row);
    }
}
