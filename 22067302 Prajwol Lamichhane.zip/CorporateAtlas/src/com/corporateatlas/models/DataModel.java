/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.corporateatlas.models;

/**
 *
 * @author lamic
 */
public class DataModel {
    private int Rank ;
    private String Name ;
    private int Revenue ;
    private int RevenuePercentChange;
    private int Profit;
    private int ProfitPercentChange;
    private int Assets;
    private int MarketValue ;
    private int Employee;
    private int ChangeinRank;

    public int getRank() {
        return Rank;
    }

    public String getName() {
        return Name;
    }

    public int getRevenue() {
        return Revenue;
    }

    public int getRevenuePercentChange() {
        return RevenuePercentChange;
    }

    public int getProfit() {
        return Profit;
    }

    public float getProfitPercentChange() {
        return ProfitPercentChange;
    }

    public int getAssets() {
        return Assets;
    }

    public int getMarketValue() {
        return MarketValue;
    }

    public int getEmployee() {
        return Employee;
    }

    public int getChange() {
        return ChangeinRank;
    }

    public DataModel(int Rank, String Name, int Revenue, int RevenuePercentChange, int Profit, int ProfitPercentChange, int Assets, int MarketValue, int Employee, int Change) {
        this.Rank = Rank;
        this.Name = Name;
        this.Revenue = Revenue;
        this.RevenuePercentChange = RevenuePercentChange;
        this.Profit = Profit;
        this.ProfitPercentChange = ProfitPercentChange;
        this.Assets = Assets;
        this.MarketValue = MarketValue;
        this.Employee = Employee;
        this.ChangeinRank = Change;
    }

    public void setRank(int Rank) {
        this.Rank = Rank;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public void setRevenue(int Revenue) {
        this.Revenue = Revenue;
    }

    public void setRevenuePercentChange(int RevenuePercentChange) {
        this.RevenuePercentChange = RevenuePercentChange;
    }

    public void setProfit(int Profit) {
        this.Profit = Profit;
    }

    public void setProfitPercentChange(int ProfitPercentChange) {
        this.ProfitPercentChange = ProfitPercentChange;
    }

    public void setAssets(int Assets) {
        this.Assets = Assets;
    }

    public void setMarketValue(int MarketValue) {
        this.MarketValue = MarketValue;
    }

    public void setEmployee(int Employee) {
        this.Employee = Employee;
    }

    public void setChange(int Change) {
        this.ChangeinRank = Change;
    }

    
    
    
}
